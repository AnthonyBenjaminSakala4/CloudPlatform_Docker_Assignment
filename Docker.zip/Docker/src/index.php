<!DOCTYPE HTML>
<html>
	<head>
		<title>Book List</title>
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<div class="container">
			<h1>Book List</h1>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
			<div class="book">
				<div class="icon">
					<img src="book.png" alt="" >
				</div>
				<div class="content">
					<h2>Book title</h2>
					<p>About the Book</p>
					<p>Quantity of the book</p>
					<span>more text about it</span>
					<button>READ IT</button>
				</div>
			</div>
		</div>
	</body>
</html>